var imgArray = ['1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg', '6.jpg', '7.jpg', '8.jpg',  '9.jpg',  '10.jpg',  '11.jpg',  '12.jpg'];
var basePath="YOUR_FOLDER_PATH_HERE";

function imgRandom() {
    alert("henlo friends")
   var pic = document.getElementById("dogImage")
   var randomNum = Math.floor(Math.random()*imgArray.length)
   pic.src = imgArray[randomNum]
   
}


var item = items[Math.floor(Math.random()*items.length)];